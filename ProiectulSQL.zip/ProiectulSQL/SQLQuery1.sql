﻿------------------------------------------------------
-- 1️ Creare baza de date
------------------------------------------------------
CREATE DATABASE LibraryDB;
GO

USE LibraryDB;
GO

------------------------------------------------------
-- 2️ Creare tabele
------------------------------------------------------

-- Tabel pentru autori
CREATE TABLE Authors (
    AuthorID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    BirthYear INT
);
GO

-- Tabel pentru cititori
CREATE TABLE Borrowers (
    BorrowerID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100),
    JoinDate DATE DEFAULT GETDATE()
);
GO

-- Tabel pentru cărți
CREATE TABLE Books (
    BookID INT IDENTITY(1,1) PRIMARY KEY,
    Title NVARCHAR(200) NOT NULL,
    AuthorID INT,
    PublishYear INT,
    Genre NVARCHAR(50),
    CONSTRAINT FK_Books_Authors FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
);
GO

-- Tabel pentru cărți împrumutate
CREATE TABLE BorrowedBooks (
    BorrowID INT IDENTITY(1,1) PRIMARY KEY,
    BookID INT,
    BorrowerID INT,
    BorrowDate DATE DEFAULT GETDATE(),
    ReturnDate DATE,
    CONSTRAINT FK_BorrowedBooks_Books FOREIGN KEY (BookID) REFERENCES Books(BookID),
    CONSTRAINT FK_BorrowedBooks_Borrowers FOREIGN KEY (BorrowerID) REFERENCES Borrowers(BorrowerID)
);
GO

------------------------------------------------------
-- 3️ Inserții de date exemplu
------------------------------------------------------

-- Inserare autori
INSERT INTO Authors (Name, BirthYear) VALUES 
('J.K. Rowling', 1965),
('George Orwell', 1903),
('Stephen King', 1947);
GO

-- Inserare cărți
INSERT INTO Books (Title, AuthorID, PublishYear, Genre) VALUES
('Harry Potter and the Sorcerer''s Stone', 1, 1997, 'Fantasy'),
('1984', 2, 1949, 'Dystopian'),
('The Shining', 3, 1977, 'Horror');
GO

-- Inserare cititori
INSERT INTO Borrowers (FullName, Email) VALUES
('Alice Smith', 'alice@example.com'),
('Bob Johnson', 'bob@example.com');
GO

-- Inserare împrumuturi
INSERT INTO BorrowedBooks (BookID, BorrowerID, BorrowDate, ReturnDate) VALUES
(1, 1, GETDATE(), DATEADD(DAY, 14, GETDATE())),
(2, 2, GETDATE(), DATEADD(DAY, 7, GETDATE()));
GO

------------------------------------------------------
-- 4️ Creare view
------------------------------------------------------

CREATE VIEW vw_BorrowedBooksDetails AS
SELECT 
    b.Title AS BookTitle,
    a.Name AS AuthorName,
    br.FullName AS BorrowerName,
    bb.BorrowDate,
    bb.ReturnDate
FROM BorrowedBooks bb
JOIN Books b ON bb.BookID = b.BookID
JOIN Authors a ON b.AuthorID = a.AuthorID
JOIN Borrowers br ON bb.BorrowerID = br.BorrowerID;
GO

------------------------------------------------------
-- 5️ Creare funcție scalară
------------------------------------------------------

CREATE FUNCTION dbo.GetBorrowDuration(@BorrowID INT)
RETURNS INT
AS
BEGIN
    DECLARE @Duration INT;
    SELECT @Duration = DATEDIFF(DAY, BorrowDate, ReturnDate)
    FROM BorrowedBooks
    WHERE BorrowID = @BorrowID;
    RETURN @Duration;
END;
GO

------------------------------------------------------
-- 6️ Creare trigger
------------------------------------------------------

CREATE TRIGGER trg_SetDefaultReturnDate
ON BorrowedBooks
AFTER INSERT
AS
BEGIN
    UPDATE BorrowedBooks
    SET ReturnDate = DATEADD(DAY, 14, BorrowDate)
    WHERE BorrowID IN (SELECT BorrowID FROM inserted) AND ReturnDate IS NULL;
END;
GO

------------------------------------------------------
-- 7️ Exemplu de interogare folosind view și funcție
------------------------------------------------------

-- Vizualizare toate cărțile împrumutate
SELECT * FROM vw_BorrowedBooksDetails;
GO

-- Calcul durata unui împrumut
SELECT dbo.GetBorrowDuration(1) AS BorrowDurationDays;
GO
